drop table emp_copy;

create table emp_copy
as 
select * from employee;

select * from emp_copy;

-- Oracle (Statment)
select01.jsp
insert01.jsp
insert01_process.jsp

-- ++
update01.jsp
update01_process.jsp
delete01.jsp
delete01_process.jsp

-- Mysql
select02.jsp
insert02.jsp
insert02_process.jsp

-- MSSQL
select03.jsp
insert03.jsp
insert03_process.jsp

-- PreparedStatement 
select05.jsp
insert05.jsp
insert05_process.jsp
update05.jsp
update05_process.jsp

delete05.jsp
delete05_process.jsp
